from setuptools import setup
setup(name='Thermal_Formatter',
      version='0.1',
      author='madebycm',
      author_email='christian.meinhold@gmail.com',
      license='MIT',
      description='A python module to prepare output for printing w/ a thermal printer',
      py_modules=['Thermal_Formatter'])
